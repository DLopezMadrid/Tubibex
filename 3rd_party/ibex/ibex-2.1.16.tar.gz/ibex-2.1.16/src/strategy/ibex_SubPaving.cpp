//============================================================================
//                                  I B E X                                   
// File        : ibex_SubPaving.cpp
// Author      : Gilles Chabert
// Copyright   : Ecole des Mines de Nantes (France)
// License     : See the LICENSE file
// Created     : May 12, 2012
// Last Update : May 12, 2012
//============================================================================

#include "ibex_SubPaving.h"

namespace ibex {


} // end namespace ibex
